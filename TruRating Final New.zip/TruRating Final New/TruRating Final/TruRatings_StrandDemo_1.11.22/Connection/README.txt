For example :
{
  "external_configuration" : [ {
    "certificate_path" : "/Connection/api_myjson_com.pem",
    "host_url" : "api.myjson.com:443"
  }]
}